public class Ej1String {
    public static void main(String[] args) {
        String cadena = "Esta es una frase cualquiera";
        String cadenaSinEspacios = cadena.replace(" ", "");
        System.out.println("La cadena con espacios: " + cadena);
        System.out.println("La cadena sin espacios: " + cadenaSinEspacios);
        

    }
}
