public class Ejercicio3String2 {
 
    
    public static void main(String[] args) {
        String frase = "Esta es una frase completa de principio a fin";
        String fraseResultado = ""; 
       

        int conteoPalabras = 1; //variable que contabiliza las palabras dentro de la frase
        int inicio = 0; //variable que indica la posición del caracter donde empieza la palabra

        // Recorremos cada carácter de la frase
        for (int i = 0; i < frase.length(); i++) {
            // Al llegar a un espacio o al último carácter de la frase
            if (frase.charAt(i) == ' ' || i == frase.length() - 1) {
                // Si estamos en el último carácter, incluimos este carácter en la palabra
                String palabra = i == frase.length() - 1 ? frase.substring(inicio, i + 1) : frase.substring(inicio, i);

                if (conteoPalabras % 2 != 0) {
                    fraseResultado += palabra + " ";
                } else {
                    //tenemos que invertir la cadena
                    String invertida = "";
                    for (int j = palabra.length() - 1; j >= 0; j--) {
                        invertida += palabra.charAt(j);
                    }
                    fraseResultado += invertida + " ";
                }
                conteoPalabras++;
                inicio = i + 1;  // Actualizar el índice de inicio de la próxima palabra
            }
        }

        System.out.println("Frase original: " + frase);
        System.out.println("Frase modificada: " + fraseResultado);
    }
    
}
