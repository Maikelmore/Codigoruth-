public class Ejercicio2String2 {
        // Dada la frase “Esta es una frase completa de principio a fin”
        // obtener un String con la misma frase, pero donde los caracteres 
        //de las posiciones pares sean mayúsculas y los caracteres de las 
        //posiciones impares minúsculas. Los espacios también cuentan como 
        //posición y se toma el carácter 0 como posición par

        public static void main(String[] args) {
            String frase = "Esta es una frase completa de principio a fin";
            String resultado="";
            for (int i = 0; i < frase.length(); i++) {
                char c = frase.charAt(i);
                if (i % 2 == 0) {
                   resultado += Character.toUpperCase(c); 
                } else {
                    resultado += Character.toLowerCase(c);
                }
            }
           System.out.println(resultado);

        }
  
}
